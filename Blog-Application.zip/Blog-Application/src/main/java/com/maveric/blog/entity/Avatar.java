package com.maveric.blog.entity;

public enum Avatar {
  DEFAULT_AVATAR,
  SMILEY_FACE,
  COOL_GLASSES,
  CAT,
  DOG,
  ROBOT,
  NINJA,
  SUPERHERO,
  ASTRONAUT,
  WIZARD,
  PIRATE,
  ALIEN
}
