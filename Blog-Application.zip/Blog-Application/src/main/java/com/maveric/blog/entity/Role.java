package com.maveric.blog.entity;

public enum Role {
  ADMIN,
  READ,
  WRITE;
}
